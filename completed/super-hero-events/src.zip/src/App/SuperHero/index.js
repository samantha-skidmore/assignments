//SUPERHERO INDEX

import React from 'react';

function SuperHero() {
    return (
        <div>
            
        </div>
    )
}

export default SuperHero;

 
