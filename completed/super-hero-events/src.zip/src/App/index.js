//APP INDEX

import React, { Component } from "react";
import superheroList from "./superheroList.js";
import SuperHero from "./SuperHero";

function App() {
    return (
        <div>
            
        </div>
    )
}

export default App;
